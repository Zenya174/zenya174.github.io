<?php
##################################################
# SMTP CONFIGURATION
##################################################
$smtp_host = ""; // YOUR SMTP HOST
$smtp_user = ""; // YOUR SMTP USER
$smpt_password = ""; // YOUR SMTP PASSWORD
$smtp_port = "465";  // Ports: 465 or 587
$smtp_secure = "ssl"; // SSL or TLS

// Your contact email info to receive contacts trough website
$contact_email = "";
